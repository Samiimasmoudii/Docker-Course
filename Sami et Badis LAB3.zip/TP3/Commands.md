1. docker build -t flaskappv0 .
2. Docker-compose up
3. Go to http://127.0.0.1:5000/date
4. cd /flask-api-user
4. docker build -t newuserapp .
5. docker-compose up

6. Apres changement de docker file et docker compose on Répète 
    4.docker build-t newuserapplocal . 
    5. docker-compose up